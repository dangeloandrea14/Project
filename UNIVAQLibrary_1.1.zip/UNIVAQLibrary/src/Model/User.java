package Model;

public class User {

    private static String email;
    private static String name;
    private static String profession;
    private static String qualification;

    public static void setEmail(String email) {
	User.email = email;
    }

    public static void setName(String name) {
	User.name = name;
    }

    public static void setProfession(String profession) {
	User.profession = profession;
    }

    public static void setQualification(String qualification) {
	User.qualification = qualification;
    }

    public static String getEmail() {
	return User.email;
    }

    public static String getName() {
	return User.name;
    }

    public static String getProfession() {
	return User.profession;
    }

    public static String getQualification() {
	return User.qualification;
    }

}
