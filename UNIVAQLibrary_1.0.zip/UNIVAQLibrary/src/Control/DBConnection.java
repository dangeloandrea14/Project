/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConnection {

    public static ResultSet query(String str) {
	try {

	    Class.forName("com.mysql.jdbc.Driver");
	    //Password for root user!!
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/libreriamanoscritti?useSSL=false", "root", "password");
	    Statement stm = con.createStatement();
	    ResultSet result = stm.executeQuery(str);

	    return result;

	} catch (Exception e) {

	    System.out.println(e.getMessage());
	    return null;
	}
    }//end method

    //method used to insert users into DB
    public static boolean update(String email, String password, String nome, String titolodistudio, String professione) {

	try {
	  

	    Class.forName("com.mysql.jdbc.Driver");
	    //Password for root user!!
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/libreriamanoscritti?useSSL=false", "root", "password");
	    Statement stm = con.createStatement();
	    stm.executeUpdate("INSERT INTO utente(ruolo,email,password,nome,titolodistudio,professione)"
		    + " values(1,'" + email + "'," + "'" + password + "'," + "'" + nome + "',"
		    + "'" + titolodistudio + "'," + "'" + professione + "'" + ")");
	   
	    return true;

	} catch (Exception e) {

	    System.out.println(e.getMessage());
	    return false;
	}
    }

}
