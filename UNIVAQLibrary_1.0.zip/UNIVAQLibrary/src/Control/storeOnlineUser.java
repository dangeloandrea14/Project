/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.User;
import java.util.ArrayList;
import java.util.Iterator;

//When a user login his information will be stored in the ArrayList
public class storeOnlineUser {
    ArrayList<User> arrayOfUser = new ArrayList<>();
    
    public storeOnlineUser(User currentUser){
	arrayOfUser.add(currentUser);
    }
    
    

    public Iterator getArrayOfUser(){
	return arrayOfUser.iterator();
    }
}
