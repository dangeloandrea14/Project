/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HomepageController implements Initializable {

    @FXML
    private TextField inputSearch;
    @FXML
    private Button search;
    @FXML
    private Button profile;
    @FXML
    private Button listWorks;
    @FXML
    private Button upload;
    @FXML
    private Button manageWorks;
    @FXML
    private Button manage;

    @FXML
    private void search(ActionEvent e) {

    }

    @FXML
    private void profile(ActionEvent e) throws Exception {
	Stage stage = (Stage) profile.getScene().getWindow(); //Source Stage!!
	Parent profile = FXMLLoader.load(getClass().getResource("/Interface/Profile.fxml"));

	Scene scene = new Scene(profile, 500, 400);
	stage.setTitle("Il tuo profilo");
	stage.setScene(scene);
	stage.show();
    }
    
    
    //elenco opere
    @FXML
    private void listWorks(ActionEvent e)throws Exception {
	Stage stage = (Stage) listWorks.getScene().getWindow(); //Source Stage!!
	Parent listaOpere = FXMLLoader.load(getClass().getResource("/Interface/ListaOpere.fxml"));

	Scene scene = new Scene(listaOpere, 900, 600);
	stage.setTitle("Lista Opere");
	stage.setScene(scene);
	stage.show();
    }

    @FXML
    private void upload(ActionEvent e) {

    }

    @FXML
    private void manageWorks(ActionEvent e) {

    }

    @FXML
    private void manage(ActionEvent e) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

}
