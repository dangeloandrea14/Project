package Control;

import Model.User;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegistrationController implements Initializable {

    @FXML
    private Button back;
    @FXML
    private Button register;
    @FXML
    private TextField email;
    @FXML
    private TextField password;
    @FXML
    private TextField name;
    @FXML
    private TextField qualification;
    @FXML
    private TextField profession;

    @FXML
    private void register(ActionEvent e) throws Exception {
	
	if (!(email.getText().equals("") && password.getText().equals(""))) {

	    DBConnection.update(email.getText(), password.getText(), name.getText(), qualification.getText(), profession.getText());
	    
	    User.setEmail(email.getText());
	    User.setName(name.getText());
	    User.setProfession(profession.getText());
	    User.setQualification(qualification.getText());
	    
	    Stage stage = (Stage) register.getScene().getWindow(); //Source Stage!!
	    Parent homepage = FXMLLoader.load(getClass().getResource("/Interface/Homepage.fxml"));

	    Scene scene = new Scene(homepage);
	    stage.setTitle("Homepage");
	    stage.setScene(scene);
	    stage.show();
	}
    }

    @FXML
    private void back(ActionEvent e) throws Exception {

	Stage stage = (Stage) back.getScene().getWindow(); //Source Stage!!
	Parent loginPage = FXMLLoader.load(getClass().getResource("/Interface/Login.fxml"));

	Scene scene = new Scene(loginPage);
	stage.setTitle("Login");
	stage.setScene(scene);
	stage.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

}
