package Control;

import Model.User;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ProfileController implements Initializable {

    @FXML
    private Button back;
    @FXML
    private Label name;
    @FXML
    private Label email;
    @FXML
    private Label profession;
    @FXML
    private Label qualification;

    @FXML
    private void back(ActionEvent e) throws Exception {
	Stage stage = (Stage) back.getScene().getWindow(); //Source Stage!!
	Parent homepage = FXMLLoader.load(getClass().getResource("/Interface/Homepage.fxml"));

	Scene scene = new Scene(homepage, 900, 600);
	stage.setTitle("Homepage");
	stage.setScene(scene);
	stage.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
	name.setText(User.getName());
	email.setText(User.getEmail());
	profession.setText(User.getProfession());
	qualification.setText(User.getQualification());
    }

}
