package Control;

import Model.User;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import javafx.stage.Stage;

public class LoginController implements Initializable {

    @FXML
    private Button login;

    @FXML
    private Button register;

    @FXML
    private TextField email;

    @FXML
    private PasswordField password;

    @FXML
    private void login(ActionEvent e) throws Exception {
	
	ResultSet userData = DBConnection.query("select email,nome,titolodistudio,password,professione,ruolo from utente");
	
	while (userData.next()) {
	   
	    if (userData.getString("email").equals(email.getText()) && userData.getString("password").equals(password.getText())) {

		User.setName(userData.getString(2));
		User.setEmail(userData.getString(1));
		User.setProfession(userData.getString(5));
		User.setQualification(userData.getString(3));

		Stage stage = (Stage) login.getScene().getWindow(); //Source Stage!!
		Parent homepage = FXMLLoader.load(getClass().getResource("/Interface/Homepage.fxml"));

		Scene scene = new Scene(homepage, 900, 600);
		stage.setTitle("Homepage");
		stage.setScene(scene);
		stage.show();
	    } else {
	    }
	}
    }

    @FXML
    private void register(ActionEvent e) throws Exception {
	Stage stage = (Stage) register.getScene().getWindow(); //Source Stage!!
	Parent registrationPage = FXMLLoader.load(getClass().getResource("/Interface/Registration.fxml"));

	Scene scene = new Scene(registrationPage, 600, 450);
	stage.setTitle("Registrati");
	stage.setScene(scene);
	stage.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

}
