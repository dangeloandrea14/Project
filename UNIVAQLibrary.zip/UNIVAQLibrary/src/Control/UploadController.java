/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Stas
 */
public class UploadController implements Initializable {

    @FXML
    private Button back;
    @FXML
    private Button selectImage;
    @FXML
    private TextField workName;
    @FXML
    private TextField numPage;
    
    private String url;

    @FXML
    private void back(ActionEvent e) throws Exception {
	Stage stage = (Stage) back.getScene().getWindow(); //Source Stage!!
	Parent homepage = FXMLLoader.load(getClass().getResource("/Interface/Homepage.fxml"));

	Scene scene = new Scene(homepage);
	stage.setTitle("Homepage");
	stage.setScene(scene);
	stage.show();
    }

    @FXML
    private void selectImage(ActionEvent e) throws SQLException, MalformedURLException {
	
	FileChooser fileChooser = new FileChooser();
	fileChooser.setTitle("Seleziona l'immagine");

	//save the selected file
	File selectedFile = fileChooser.showOpenDialog(appEntry.getStage());
	url = selectedFile.toURI().toURL().toExternalForm();
	String newUrl = "/" + url.substring(5);
	
	if (selectedFile != null) {
	    ResultSet idWork = DBConnection.query("select manoscritto from page p, manoscritto m where p.manoscritto= m.ID and m.titolo = " + "'" + workName.getText() + "'");
	    
	    while(idWork.next()){
		DBConnection.uploadPage( Integer.parseInt(numPage.getText()),idWork.getInt(1), newUrl);
	    }
	   
	    
	}
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
	// TODO
    }

}
