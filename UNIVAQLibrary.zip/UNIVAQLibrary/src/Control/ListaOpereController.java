/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import javax.imageio.ImageIO;

public class ListaOpereController implements Initializable {

    @FXML
    private ImageView selectedImage;
    @FXML
    private ListView list;
    @FXML
    private Button download;
    @FXML
    private Button homepage;
    
    private String currentSelectedImage;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
	ResultSet scanPath = DBConnection.query("select scanpath from page where manoscritto = " + HomepageController.getManoscrittoID());
	ObservableList<ImageView> listImage = FXCollections.observableArrayList();
	
	
	//selectedImage.setImage(new Image(scanPath.getString(1)));
	
	//add imageview to listImage	
	try {
	    while(scanPath.next()){
		
		listImage.add(generateImage(scanPath.getString(1)));	
	    }
	} catch (SQLException ex) {
	    System.out.println("Error: ->" + ex.getMessage());
	} catch (MalformedURLException ex) {
	    Logger.getLogger(ListaOpereController.class.getName()).log(Level.SEVERE, null, ex);
	}
	
	list.setItems(listImage);
	list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
	list.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<ImageView>() {
	    @Override
	    public void changed(ObservableValue<? extends ImageView> observable, ImageView oldValue, ImageView newValue) {
//		borderPane.setCenter(newValue);
		selectedImage.setImage(newValue.getImage());
		currentSelectedImage = observable.getValue().getImage().impl_getUrl();
		
		//image path
	    }

	});
	
    }   
    
    @FXML
    private void goHomepage(ActionEvent e)throws Exception{
	Stage stage = (Stage) homepage.getScene().getWindow(); //Source Stage!!
	Parent homepage = FXMLLoader.load(getClass().getResource("/Interface/Homepage.fxml"));

	Scene scene = new Scene(homepage, 900, 600);
	stage.setTitle("Homepage");
	stage.setScene(scene);
	stage.show();
    }
    
    public ImageView generateImage(String pathImage) throws MalformedURLException{
	File file = new File(pathImage);
	ImageView container = new ImageView(new Image(file.toURI().toURL().toExternalForm()));
	
	container.setFitHeight(120);
	container.setFitWidth(120);
	return container;
    }
    
    @FXML
    private void download(){
	
	FileChooser fileChooser = new FileChooser();
	
	fileChooser.setTitle("Scegli dove salvare");
	
	File file = fileChooser.showSaveDialog(appEntry.getStage());
	if(file != null){
	    try{
		ImageIO.write(SwingFXUtils.fromFXImage(selectedImage.getImage(),
                        null), "png", file);
	    }catch(IOException ex){
		System.out.println(ex.getMessage());
	    }
	}
	
    }
    
    
    
         private void SaveFile(String content, File file){
        try {
            FileWriter fileWriter = null;
             
            fileWriter = new FileWriter(file);
            fileWriter.write(content);
            fileWriter.close();
        } catch (IOException ex) {
           System.out.println(ex.getMessage());
        }
         
    }
}
